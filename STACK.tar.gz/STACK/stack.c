

/**********************************************************
* File : Stack.c
* Author : AK
* STACK demonstration using Static Memory Allocation (Array)
*
**********************************************************/

#include <stdio.h>
#include <stdlib.h>
#include "stack.h"

//############################################################ Define & Declare  ######################################################################################

#define CAPACITY 5 // Preprocessor Directive 

int stack [CAPACITY]; // Only Macro can be used because it is substituted during preprocessing 
int top = -1; // -1 because Index starts from 0

//############################################################ Main Function ######################################################################################


int main()
{
int opt,Item;
while (1)
{
printf("####################################\n");
printf("##### PLEASE SELECT ONE OPTION #####\n");
printf("####################################\n");
printf("1)Push\n2)Pop\n3)Traverse\n4)Peek\n5)Exit\n");
printf("####################################\n");
scanf("%d",&opt);
printf("You Selected => %d \n",opt);

switch (opt)
{
case 1: // Push Function
printf("Enter Element to Push \n");
scanf("%d",&Item);
Push(Item);
break;

case 2: // Pop Function
Item = Pop();
if (Item == 0)
{
printf("##=> Stack is Empty <=##\n");
}
else
{
printf("Popped Item is %d\n",Item);
}
break;

case 3: // Traverse
Traverse();
break; 

case 4: // Peek
Item = Peek();
if(Item == 0)
{
printf("##=> Stack is Empty <=##\n");
}
else
{
printf("##=> PEEK is %d <=##\n",Item);
}
break;

case 5: // Exit
printf("Exiting !! Thank You\n");
exit (0);
break;

default:
printf("!!!! Select On Appropriate Option\n");
break;

}
}
}


//##################################################### Traverse (Traversing inside Stack) ##########################################################################

/*****************************************************
* int Traverse ()
*
* Parameters
*
* I/P = None , O/P None 
*
* Return : 0 for Empty Stack and  Prints Stack on success 
*
******************************************************/

int Traverse()
{
int ind;
if(isEmpty())
{
printf("##=> Stack is Empty <=##\n");
return 0;
}
else
{
printf("Stack Elements are\n");
for(ind=0;ind<=top;ind++)
{
printf("stack[%d]=%d\n",ind,stack[ind]);

}

}

}


//##################################################### Peek (Returns Top Element But wont delete) ##########################################################################


/*****************************************************
* int Peek()
*
* Parameters
*
* I/P = None , O/P None 
*
* Return : 0 for Empty Stack and Top Element on success 
*
******************************************************/

int Peek()
{
int Ele;
if(isEmpty())
{
printf("##=> Stack is Empty <=##\n");
return 0;
}
else
{
return stack[top];
}

}




//##################################################### Pop (Returns Top Element and delete it) ##############################################################################


/*****************************************************
* int Pop ()
*
* Parameters
*
* I/P = None , O/P None 
*
* Return : 0 for Empty Stack  or else  Popped Element in the stack 
*
******************************************************/



int Pop()
{
if(isEmpty())
{
printf("##=> Stack is Empty <=##\n");
return 0;
}
else
{
return stack[top--];
}
}


//######################################################### Push() ###########################################################################


/*****************************************************
* int Push()
*
* Parameters
*
* I/P = Ele , O/P None 
*
* Return : 0 if Stack is full Or else  Prints the element Pushed 
*
******************************************************/

void Push (int Ele)
{
if(isFull())
{
printf("##Stack is Full##\n");
}
else
{
top++;
stack[top]=Ele;
printf("Element is Pushed into stack %d\n",Ele);
}
}

//######################################################## isFull ############################################################################


/*****************************************************
* int isFull ()
*
* Parameters
*
* I/P = None , O/P None 
*
* Return : 1 if Stack is Full and 0 if stack is not full
*
******************************************************/


int isFull()
{
if(top == (CAPACITY-1))
{
return 1;
}
else
{
return 0;
}
}


//############################################################ isEmpty #########################################################################


/*****************************************************
* int isEmpty ()
*
* Parameters
*
* I/P = None , O/P None 
*
* Return : 1 for Empty Stack and 0 for Non-Empty stack
*
******************************************************/


int isEmpty()
{
if(top == -1)
{
return 1;
}
else
{
return 0;
}

}



//#####################################################################################################################################



