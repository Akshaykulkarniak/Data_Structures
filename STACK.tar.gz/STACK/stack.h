/**********************************************************
* File : Stack.h
* Author : AK
* STACK demonstration using Static Memory Allocation (Array)
*
**********************************************************/





int Traverse();
int Peek();
int Pop();
void Push (int Ele);
int isFull();
int isEmpty();


